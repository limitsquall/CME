# -*- coding: utf-8 -*-
"""

Exercise 06 

"""

import numpy as np
import matplotlib.pyplot as plt
from ase.units import kB

time, etot, pe, ke, T = np.loadtxt('md_fine.log', skiprows=1, unpack=True)

plt.plot(time, etot, label='Etot')
plt.plot(time, pe, label='PE')
plt.plot(time, ke, label='KE')
plt.legend()
plt.xlabel('Time (ps)')
plt.ylabel('Energy (eV)')
plt.savefig('en_time.png', dpi=300)

print(ke[1]/(3./2 * kB * 2), T[1])
plt.show()

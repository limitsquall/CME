# -*- coding: utf-8 -*-
"""

Exercise 06 

"""

import numpy as np
from ase.io import read
import matplotlib.pyplot as plt


def cosine(x, A, omega, B):
    return A * np.cos(omega * x) + B


traj = read('md.xyz@:')
d = []
time = np.linspace(0, 200, 201)

for image in traj:
    d.append(image.get_distance(0, 1))

plt.plot(time, d, 'ro', label='Data', linewidth=1)
#plt.plot(np.arange(len(traj)) * 10, d, 'ro--', label='Data', linewidth=1)
plt.xlabel('Time (fs)')
plt.ylabel('Distance ($\AA$)')
plt.savefig('dist_time.png', dpi=300)

xdata = np.linspace(0, 200, 100)
#plt.plot(xdata, cosine(xdata, -0.05, 0.19567, 1), label='Cosine',linewidth=3)
plt.plot(xdata, cosine(xdata, -0.5, 0.19567, 1), label='Cosine',linewidth=3)

plt.legend()
plt.savefig('Cosine_fit.png', dpi=300)

#plt.xlim([0, 33])
plt.show()
